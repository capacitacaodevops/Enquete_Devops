#!/bin/sh

PWD=$(pwd)

ls $PWD
