{
  "name": "nodemysql",
  "version": "1.0.0",
  "description": "tutorial de node com mysql",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "luiztools",
  "license": "ISC"
}

