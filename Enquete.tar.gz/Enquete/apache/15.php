<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>ENQUETE</title>
        	<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>

	</head>

	 <style>


		.whitetext { color: white }

		.radial-gradient {
			background-color: rgb(0, 58, 85);
    			
		}

		.image {
                position: left;
		}

#cronometro {
  font-family: 'Courier New';
  font-weight: bold;
/*  letter-spacing: 5px;*/
  font-size: 60px;
  background: red;
  color: white;
/*  padding: 1px 1px 1px 1px; */
  width: 120px;
  margin: 0cm 0cm 0cm 4cm; 
  border-radius: 12px;
  text-align: right;
}

#controles {
/*  margin: 1cm 2cm 1cm 1cm; */
  text-align: center;
  margin: 10px; 
  color: white;
/*  margin-bottom: 15px; */
/*  margin-left: 6px; */
/*  margin-right: 6px; */
}

body {
  background: black;
}

div#cronometro {
  width: 360px;
  height: 60px;
  text-align: center;
}

/* campo minutos e segundos */

input#intervaloAlarmeMinutos {
  margin-left: 50px;
  margin-right: 50px;
}

	</style>

    
	
	<body class="radial-gradient">

     
		<!-- # outra opcao para deixar a cor de background diferente no style, 
		body { background-color: rgb(0, 0, 106); /* Standard syntax (must be last) */} -->

                <center><h2 class="whitetext">"ENQUETE" </h2></center>
		
		<?php 

		   	$json = file_get_contents("http://172.17.0.1:3000/perguntas/15");

			/*
			converter o json em php
			*/
			//String no formato JSON
			$json = json_decode($json);
			
			//Manipulando o objeto decodificado e imprimindo as alternativas na tela
			echo "<h2 style='color:rgb(255, 255, 170);'> ID: ".$json[0]->id;
			echo "<br />";
			echo "QUESTÃO: ".$json[0]->questao;
			echo "<br />";
			echo "<br />";
			echo "(A) ".$json[0]->a;
			echo "<br />";
			echo "(B) ".$json[0]->b;
			echo "<br />";
			echo "(C) ".$json[0]->c;
			echo "<br />";
			echo "(D) ".$json[0]->d;
			echo "<br />";
			echo "<br /> </h2>";
 			

			
			//jogando as alternativas para variaveis		
			
			$A="".$json[0]->a;
			$B="".$json[0]->b;
			$C="".$json[0]->c;
			$D="".$json[0]->d;	
			$resposta ="".$json[0]->r;
			$resposta2 ="".$json[0]->r2;
			$respostaShow1 ="Resposta: ".$json[0]->r;
			$respostaShow2 ="...".$json[0]->r2;
			
			//imprimindo as variaveis na tela para testes
			/*	
			echo $A;
			echo $B;
			echo $C;
			echo $D;
			echo $resposta;
			echo $resposta2;
			echo $respostaShow1;
			echo $respostaShow2;
			*/
		
	
			?>


		<p><img src="images/perguntas.png" align="right" height="150" width="170"><br>


		<h2 style='color:white;' onclick="this.innerHTML=id=respostaShow1"> Resposta:</h2> 
		<h2 style='color:white;' onclick="this.innerHTML=id=respostaShow2"> ...</h2>

		<script>
		
			//resposta
		var respostaShow1 = "<?php print $respostaShow1; ?>";
		var respostaShow2 = "<?php print $respostaShow2; ?>";
		
		document.getElementById("respostaShow1").innerHTML = " Valor da resposta: " + respostaShow1;
		document.getElementById("respostaShow2").innerHTML = "... " + respostaShow2;


		</script>		
	

		<audio id="certa">
    		<source /src="sound/certa-resposta.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>
 
		<audio id="errada">
    		<source src="sound/errada-resposta.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>

		<audio id="coracao">
    		<source src="sound/coracao_batendo.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>

		<audio id="vento">
    		<source src="sound/vento.mp3" type="audio/mpeg">/
   			 Seu navegador não possui suporte ao elemento audio
		
		</audio>

		<audio id="inicio">
    		<source src="sound/inicioP.mp3" type="audio/mpeg">/
   			 Seu navegador não possui suporte ao elemento audio
		
		</audio>

		   		<script>
			
			//gerando id para as variaveis com apontamento para arquivos de audio
				certa = document.getElementById('certa');
				errada = document.getElementById('errada');
				coracao = document.getElementById('coracao');
				vento = document.getElementById('vento');
				inicio = document.getElementById('inicio');


			//funcoes apontando para as variaveis de audio
 
    			function certaf(){
        			certa.play();
    			        	}
	
			function stop(){
        			audio.pause();
        			audio.currentTime = 0;
        			vento.pause();
        			vento.currentTime = 0;
					}

    			function erradaf(){
        			console.log(this);
				errada.play();
    					}

			function coracaof(){
        			console.log(this);
				coracao.play();
    					}

			function ventof(){
        			console.log(this);
				vento.play();
    					}
	
			function iniciof(){
        			console.log(this);
				inicio.play();
    					}
	
				
			//funcao de audio para verificar resposta certa ou errada


				
			//var respostaJ = "<?php print $resposta; ?>";
			//	var alternativaA = "<?php print $A; ?>";
			
			function audioFunctionA(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaA = "<?php print $A; ?>";

					if (alternativaA === respostaJ ) {
						certa.play();
						document.getElementById("buttonA").style.backgroundColor = "green";

					} else {
						errada.play();
						document.getElementById("buttonA").style.backgroundColor = "red";
					}
				}

			
			function audioFunctionB(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaB = "<?php print $B; ?>";

					if (alternativaB === respostaJ ) {
						certa.play();
						document.getElementById("buttonB").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonB").style.backgroundColor = "red";
					}
				}

		        	
			function audioFunctionC(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaC = "<?php print $C; ?>";

					if (alternativaC === respostaJ ) {
						certa.play();
						document.getElementById("buttonC").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonC").style.backgroundColor = "red";
					}
				}

			
			function audioFunctionD(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaD = "<?php print $D; ?>";

					if (alternativaD === respostaJ ) {
						certa.play();
						document.getElementById("buttonD").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonD").style.backgroundColor = "red";
					}
				}

		
			//Tocar audio inicial
			inicio.play();
			
			//apenas para teste
				//audioFunction();


				window.onload = function() {
  var divCronometro = document.getElementById("cronometro");
  var btnIniciar = document.getElementById("iniciar");
  var btnParar = document.getElementById("parar");
  var btnZerar = document.getElementById("zerar");
  var intervaloSegundos = document.getElementById("intervaloAlarme");
  new Cronometro(divCronometro, btnIniciar, btnParar, btnZerar, intervaloAlarmeMinutos, intervaloAlarmeSegundos);
}

var Cronometro = function(div, btnIniciar, btnParar, btnZerar, inputIntervaloMinutos, inputIntervaloSegundos) {
  var este = this;
  this.estado = null;
  this.hora = 0;
  this.minuto = 0;
  this.segundo = 0;
  this.intervaloAlarmeMinutos = 0;
  this.intervaloAlarmeSegundos = 0;
  this.start = false;

  // criando elemento html5 audio
  this.audio = document.createElement('audio');
  this.sourceAudio = document.createElement('source');
  this.sourceAudio.setAttribute('src', 'http://www.online-clockalarm.com/sounds/sound3.mp3');
  this.sourceAudio.setAttribute('type', 'audio/mp3');
  this.audio.appendChild(this.sourceAudio);

  this.atualizar = function() {
    var str = (este.hora < 10 ? "0" +
        este.hora : este.hora) + ":" +
      (este.minuto < 10 ? "0" + este.minuto : este.minuto) + ":" +
      (este.segundo < 10 ? "0" + este.segundo : este.segundo);
    div.innerHTML = str;
  }
  this.iniciar = function() {
    if (!este.start) {
      este.estado = setInterval(function() {
        este.segundo += 1;
        if (este.segundo % 60 == 0) {
          este.segundo = 0;
          este.minuto += 1;
        }
        if (este.minuto % 60 == 0 && este.minuto > 0) {
          este.minuto = 0;
          este.hora += 1;
        }
        este.atualizar();
        este.verificaAlarme();
      }, 1000);
      este.start = true;
    }
  }
  this.parar = function() {
    clearInterval(este.estado);
    este.start = false;
  }
  this.zerar = function() {
    este.hora = 0;
    este.minuto = 0;
    este.segundo = 0;
    este.atualizar();
  }
  this.setIntervaloAlarmeMinutos = function(minutos) {
    este.intervaloAlarmeMinutos = minutos;
  }
  this.setIntervaloAlarmeSegundos = function(segundos) {
    este.intervaloAlarmeSegundos = segundos;
  }
  this.verificaAlarme = function() {
    if (este.intervaloAlarmeMinutos != 0 || este.intervaloAlarmeSegundos != 0) {
      var segundosTotais = este.hora * 3600 + este.minuto * 60 + este.segundo;
      var intervaloAlarmeSegundosTotais = parseInt(este.intervaloAlarmeMinutos * 60) + parseInt(este.intervaloAlarmeSegundos);
      if (segundosTotais % intervaloAlarmeSegundosTotais == 0) {
        este.audio.play();
      };
    }
  }

  // Adicionando listeners
  if (document.addEventListener) {
    inputIntervaloSegundos.addEventListener("change", function() {
      este.setIntervaloAlarmeSegundos(inputIntervaloSegundos.value);
    });
    inputIntervaloMinutos.addEventListener("change", function() {
      este.setIntervaloAlarmeMinutos(inputIntervaloMinutos.value);
    });
    btnIniciar.addEventListener("click", function() {
      este.iniciar();
    });
    btnParar.addEventListener("click", function() {
      este.parar();
    });
    btnZerar.addEventListener("click", function() {
      este.zerar();
    });

  } else {
    inputIntervaloMinutos.addAttachEvent("onChange", function() {
      este.setIntervaloAlarmeMinutos(inputIntervaloMinutos.value);
    });
    inputIntervaloSegundos.addAttachEvent("onChange", function() {
      este.setIntervaloAlarmeSegundos(inputIntervaloSegundos.value);
    });
    btnIniciar.addAttachEvent("onClick", function() {
      este.iniciar();
    });
    btnParar.addAttachEvent("onClick", function() {
      c.parar();
    });
    btnZerar.addAttachEvent("onClick", function() {
      c.zerar();
    });
  }
};

						                
	</script>



    <div style="text-align: center; width: 5%;">

	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonA" value="A" onClick="javascript:audioFunctionA();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonB" value="B" onClick="javascript:audioFunctionB();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonC" value="C" onClick="javascript:audioFunctionC();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonD" value="D" onClick="javascript:audioFunctionD();"/>


    </div>

     <div id="cronometro">00:00:00</div>
		
		<div id="controles">
                 <span>Definir intervalo de alarme</span>
                 <p>
                <input type="number" id="intervaloAlarmeMinutos" value="0" max="60" min="0" />
                <span>Minutos</span>
                <input type="number" id="intervaloAlarmeSegundos" value="0" max="59" min="0" />
                <span>Segundos</span>
                <p>
                <button id="iniciar">Iniciar</button>
                <button id="parar">Parar</button>
                <button id="zerar">Zerar</button>
        </div>



    <div style="text-align: center; width: 100%;">


	<input type="button" name="button" id="button" value="Coração" onClick="javascript:coracaof();"/>
	<input type="button" name="button" id="button" value="Vento" onClick="javascript:ventof();"/>
	<input type="button" name="button" id="button" value="Stop" onClick="javascript:stop();"/>

    </div>


   </body>

 </html>
