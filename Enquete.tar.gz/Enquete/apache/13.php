<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>ENQUETE</title>
        	<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>

	</head>

	 <style>


		.whitetext { color: white }

		.radial-gradient {
			background-color: rgb(0, 58, 85);
    			
		}

		.image {
                position: left;
                }


	</style>

    
	
	<body class="radial-gradient">

     
		<!-- # outra opcao para deixar a cor de background diferente no style, 
		body { background-color: rgb(0, 0, 106); /* Standard syntax (must be last) */} -->

                <center><h2 class="whitetext">"ENQUETE" </h2></center>
		
		<?php 

		   	$json = file_get_contents("http://172.17.0.1:3000/perguntas/13");

			/*
			converter o json em php
			*/
			//String no formato JSON
			$json = json_decode($json);
			
			//Manipulando o objeto decodificado e imprimindo as alternativas na tela
			echo "<h2 style='color:rgb(255, 255, 170);'> ID: ".$json[0]->id;
			echo "<br />";
			echo "QUESTÃO: ".$json[0]->questao;
			echo "<br />";
			echo "<br />";
			echo "(A) ".$json[0]->a;
			echo "<br />";
			echo "(B) ".$json[0]->b;
			echo "<br />";
			echo "(C) ".$json[0]->c;
			echo "<br />";
			echo "(D) ".$json[0]->d;
			echo "<br />";
			echo "<br /> </h2>";
 			

			
			//jogando as alternativas para variaveis		
			
			$A="".$json[0]->a;
			$B="".$json[0]->b;
			$C="".$json[0]->c;
			$D="".$json[0]->d;	
			$resposta ="".$json[0]->r;
			$resposta2 ="".$json[0]->r2;
			$respostaShow1 ="Resposta: ".$json[0]->r;
			$respostaShow2 ="...".$json[0]->r2;
			
			//imprimindo as variaveis na tela para testes
			/*	
			echo $A;
			echo $B;
			echo $C;
			echo $D;
			echo $resposta;
			echo $resposta2;
			echo $respostaShow1;
			echo $respostaShow2;
			*/
		
	
			?>


		<p><img src="images/perguntas.png" align="right" height="150" width="170"><br>


		<h2 style='color:white;' onclick="this.innerHTML=id=respostaShow1"> Resposta:</h2> 
		<h2 style='color:white;' onclick="this.innerHTML=id=respostaShow2"> ...</h2>

		<script>
		
			//resposta
		var respostaShow1 = "<?php print $respostaShow1; ?>";
		var respostaShow2 = "<?php print $respostaShow2; ?>";
		
		document.getElementById("respostaShow1").innerHTML = " Valor da resposta: " + respostaShow1;
		document.getElementById("respostaShow2").innerHTML = "... " + respostaShow2;


		</script>		
	

		<audio id="certa">
    		<source /src="sound/certa-resposta.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>
 
		<audio id="errada">
    		<source src="sound/errada-resposta.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>

		<audio id="coracao">
    		<source src="sound/coracao_batendo.mp3" type="audio/mpeg">
    		Seu navegador não possui suporte ao elemento audio
		</audio>

		<audio id="vento">
    		<source src="sound/vento.mp3" type="audio/mpeg">/
   			 Seu navegador não possui suporte ao elemento audio
		
		</audio>

		<audio id="inicio">
    		<source src="sound/inicioP.mp3" type="audio/mpeg">/
   			 Seu navegador não possui suporte ao elemento audio
		
		</audio>

		   		<script>
			
			//gerando id para as variaveis com apontamento para arquivos de audio
				certa = document.getElementById('certa');
				errada = document.getElementById('errada');
				coracao = document.getElementById('coracao');
				vento = document.getElementById('vento');
				inicio = document.getElementById('inicio');
			
			//funcoes apontando para as variaveis de audio
 
    			function certaf(){
        			certa.play();
    			        	}
	
			function stop(){
        			audio.pause();
        			audio.currentTime = 0;
        			vento.pause();
        			vento.currentTime = 0;
					}

    			function erradaf(){
        			console.log(this);
				errada.play();
    					}

			function coracaof(){
        			console.log(this);
				coracao.play();
    					}

			function ventof(){
        			console.log(this);
				vento.play();
    					}
	
			function iniciof(){
        			console.log(this);
				inicio.play();
    					}
	
				
			//funcao de audio para verificar resposta certa ou errada


				
			//var respostaJ = "<?php print $resposta; ?>";
			//	var alternativaA = "<?php print $A; ?>";
			
			function audioFunctionA(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaA = "<?php print $A; ?>";

					if (alternativaA === respostaJ ) {
						certa.play();
						document.getElementById("buttonA").style.backgroundColor = "green";

					} else {
						errada.play();
						document.getElementById("buttonA").style.backgroundColor = "red";
					}
				}

			
			function audioFunctionB(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaB = "<?php print $B; ?>";

					if (alternativaB === respostaJ ) {
						certa.play();
						document.getElementById("buttonB").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonB").style.backgroundColor = "red";
					}
				}

		        	
			function audioFunctionC(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaC = "<?php print $C; ?>";

					if (alternativaC === respostaJ ) {
						certa.play();
						document.getElementById("buttonC").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonC").style.backgroundColor = "red";
					}
				}

			
			function audioFunctionD(elem) {
				var respostaJ = "<?php print $resposta; ?>";
				var alternativaD = "<?php print $D; ?>";

					if (alternativaD === respostaJ ) {
						certa.play();
						document.getElementById("buttonD").style.backgroundColor = "green";
					} else {
						errada.play();
						document.getElementById("buttonD").style.backgroundColor = "red";
					}
				}

		
			//Tocar audio inicial
			inicio.play();
			
			//apenas para teste
			//audioFunction();
						                
	</script>



    <div style="text-align: center; width: 5%;">

	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonA" value="A" onClick="javascript:audioFunctionA();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonB" value="B" onClick="javascript:audioFunctionB();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonC" value="C" onClick="javascript:audioFunctionC();"/>
	<input style="margin-right: 30px; width: 40px; height: 40px" type="button" name="button" id="buttonD" value="D" onClick="javascript:audioFunctionD();"/>

    </div>



    <div style="text-align: center; width: 100%;">

	<input type="button" name="button" id="button" value="Coração" onClick="javascript:coracaof();"/>
	<input type="button" name="button" id="button" value="Vento" onClick="javascript:ventof();"/>
	<input type="button" name="button" id="button" value="Stop" onClick="javascript:stop();"/>


    </div>


   </body>

 </html>
