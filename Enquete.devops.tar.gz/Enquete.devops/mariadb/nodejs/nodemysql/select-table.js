function execSQLQuery(sqlQry, res){
  const connection = mysql.createConnection({
    host     : '192.168.0.140',
    port     : '3306',
    user     : 'root',
    password : 'senhadoroot',
    database : 'enquete'
  });

  connection.query(sqlQry, function(error, results, fields){
      if(error) 
        res.json(error);
      else
        res.json(results);
      connection.end();
      console.log('executou!');
  });
}

router.get('/perguntas', (req, res) =>{
    execSQLQuery('SELECT * FROM perguntas', res);
})

router.get('/perguntas/:id?', (req, res) =>{
    let filter = '';
    if(req.params.id) filter = ' WHERE ID=' + parseInt(req.params.id);
    execSQLQuery('SELECT * FROM Clientes' + filter, res);
})
