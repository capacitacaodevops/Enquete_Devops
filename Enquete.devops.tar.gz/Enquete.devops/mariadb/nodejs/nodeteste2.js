var mysql = require('mysql');

var con = mysql.createConnection({
  host: "192.168.0.140",
  user: "root",
  password: "senhadoroot"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});
